import React from 'react'

const FMECATable: React.FC = () => {
  return (
    <></>
  )
}

export default FMECATable