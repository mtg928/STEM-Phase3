const Loading = () => (
  <div style={{ paddingTop: 100, textAlign: 'center' }}>
    Loading...
  </div>
)

export default Loading
