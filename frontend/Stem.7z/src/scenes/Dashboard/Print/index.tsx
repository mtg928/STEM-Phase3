import React from 'react'

const PrintPage: React.FC = () => {
  return (
    <></>
  )
}

export default PrintPage