import React from 'react'

const ScreenshotPage: React.FC = () => {
  return (
    <></>
  )
}

export default ScreenshotPage